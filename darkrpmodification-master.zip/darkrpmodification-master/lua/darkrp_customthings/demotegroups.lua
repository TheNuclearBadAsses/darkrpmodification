--[[---------------------------------------------------------------------------
Demote groups
---------------------------------------------------------------------------
When a chief of police gets demoted you don't want them to be banned from becoming civil protection officer as well.
That is what demote groups are for.

When someone in a group is demoted, they will be banned from EVERY job in the group.
The examples shown below are the default demote groups

HOW TO CREATE A DEMOTE GROUP:
DarkRP.createDemoteGroup("Name of the group", {TEAM1, TEAM2})
---------------------------------------------------------------------------]]
--[[

    These are the Demote groups, We are going to get rid of them.

]]
DarkRP.createDemoteGroup("Goverment", {TEAM_JUGGERNAUT,TEAM_DAUGHTER,TEAM_CHIEF,TEAM_MAYOR,TEAM_NYPD,TEAM_SPIDERMAN,TEAM_DAUGHTER,TEAM_BATMAN})
DarkRP.createDemoteGroup("Thiefs", {TEAM_THIEF,TEAM_PROTHIEF,TEAM_ELITETHIEF})
DarkRP.createDemoteGroup("Russians", {TEAM_RUSSIAN,TEAM_RUSSIANMOB})
DarkRP.createDemoteGroup("Italians", {TEAM_ITALIAN,TEAM_ITALIANMOB})
DarkRP.createDemoteGroup("Rapist", {TEAM_RAPIST})
DarkRP.createDemoteGroup("Terrorist", {TEAM_TERRORISTLEADER,TEAM_TERROR})
DarkRP.createDemoteGroup("Hitman", {TEAM_ELITEHITMAN,TEAM_HITMAN})
DarkRP.createDemoteGroup("Dealers", {TEAM_BLACKMARKETDEALER,TEAM_HEAVYGUN,TEAM_GUN,TEAM_KNIFE})
DarkRP.createDemoteGroup("Hobo", {TEAM_HOBO})


-- Redone 7/11/2017
DarkRP.createDemoteGroup("Hotel Manager", {TEAM_HOTELMANAGER})
--]]